package com.linkcode.controller.APIExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
