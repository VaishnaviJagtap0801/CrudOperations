package com.linkcode.controller;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {
	
	@Autowired
	SessionFactory factory;
	
	
	@GetMapping("getRegister/{REGID}")
	public Register getRegister(@PathVariable int REGID){
		Session session=factory.openSession();
		Register register=session.get(Register.class,REGID);
		return register;
		
}
	
	//save data in database using postman
	@PostMapping("saveRegister")
	public String savRegister(@RequestBody Register register){
		
		System.out.println("data from postman added into register object ");
		System.out.println(register);
		Session session=factory.openSession();
		session.save(register);
		session.beginTransaction().commit();
		return "data saved!!";
	
		
	}
	
	//update data 
	@PutMapping("updateRegister")
	public String updateRegister(@RequestBody Register register) {
		
		System.out.println("data from postman updated into register object ");
		System.out.println(register);
		Session session=factory.openSession();
		session.update(register);
		session.beginTransaction().commit();
		
		return "data updated!!";
		
	}
	
	//delete data 
	
	@DeleteMapping("deleteRegister/{REGID}")
	public String deleteRegister(@PathVariable int REGID) {
		
		Session session=factory.openSession();
		Register register=session.get(Register.class,REGID);
		
		session.delete(register);
		session.beginTransaction().commit();
		
		return "data deleted!!";
		
	}
	
	//get all records from database tables
	@GetMapping("getAllRegister")
	public List<Register> getAllRegister(){
		
		Session session=factory.openSession();
		
		//criteria method is used to fetch the record based on the condition(but here we have not applied condition).
		Criteria criteria=session.createCriteria(Register.class);
		
		
		List<Register> list=criteria.list();
		return list;
		
	}
	
	
	//criteria method is used to fetch the record based on the condition
	@GetMapping("getRegister1/{lower}/{upper}")
	public List<Register> getRegister1(@PathVariable int lower,@PathVariable int upper){
		
		Session session=factory.openSession();
		
		//criteria method is used to fetch the record based on the condition(but here we have not applied condition).
		Criteria criteria=session.createCriteria(Register.class);
		
       // criteria.add(Restrictions.le("REGID",10));
		  criteria.add(Restrictions.between("REGID",lower,upper));
		  
		List<Register> list=criteria.list();
		return list;
		
	}

}
