package com.linkcode.controller;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Register {
	@Id
	private int REGID;
	private String REGNAME;
	private String REGEMAIL;
	private String REGPASSWORD;
	public int getREGID() {
		return REGID;
	}
	public void setREGID(int rEGID) {
		REGID = rEGID;
	}
	public String getREGNAME() {
		return REGNAME;
	}
	public void setREGNAME(String rEGNAME) {
		REGNAME = rEGNAME;
	}
	public String getREGEMAIL() {
		return REGEMAIL;
	}
	public void setREGEMAIL(String rEGEMAIL) {
		REGEMAIL = rEGEMAIL;
	}
	public String getREGPASSWORD() {
		return REGPASSWORD;
	}
	public void setREGPASSWORD(String rEGPASSWORD) {
		REGPASSWORD = rEGPASSWORD;
	}
	@Override
	public String toString() {
		return "Register [REGID=" + REGID + ", REGNAME=" + REGNAME + ", REGEMAIL=" + REGEMAIL + ", REGPASSWORD="
				+ REGPASSWORD + "]";
	}
	
	
	
	

}
